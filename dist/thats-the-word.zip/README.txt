		==================================================
				that's the word
		==================================================


				AUTHOR: IBRAHIM SIKIRU
				VERSION: 0.1


that's the word (ttw) is a simple Java application that gives you a list of all the words in a 
selected language, of a specified length, that contain all or some of the letters you provided.
